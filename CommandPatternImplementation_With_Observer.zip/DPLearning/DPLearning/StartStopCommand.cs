﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: StartCommand.cs
// ----------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace DPLearning
{
    public class StartStopCommand : ICommand
    {
        private Vehicle _vehicle;
        private List<IObserver> _observers;

        public StartStopCommand(Vehicle vehicle, List<IObserver> observers)
        {
            _vehicle = vehicle;
            _observers = observers;
            foreach (var observer in _observers)
            {
                observer.Subscribe();
            }
        }

        public void Execute(string parameter)
        {
            if (parameter.ToUpper() == "START")
            {
                _vehicle.Start();
            }
            else if(parameter.ToUpper()=="STOP")
            {
                _vehicle.Stop();
            }
            else
            {
                Console.WriteLine("Incorrect instruction received");
                return;
            }
            foreach (var observer in _observers)
            {
                observer.Notify(_vehicle.GetVehicleState());
            }
        }
    }
}