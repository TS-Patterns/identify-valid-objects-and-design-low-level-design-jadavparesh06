﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: SMSObserver.cs
// ----------------------------------------------------------------------------------------

using System;

namespace DPLearning
{
    public class SMSObserver : IObserver
    {
        private bool _isSubscribed = false;

        public void Subscribe()
        {
            _isSubscribed = true;
        }

        public void UnSubscribe()
        {
            _isSubscribed = false;
        }

        public void Notify(bool state)
        {
            if (_isSubscribed)
            {
                string vehicleState = state ? "ON" : "OFF";
                Console.WriteLine($"SMS Notification : Vehicle State :{vehicleState}");
            }
        }
    }
}