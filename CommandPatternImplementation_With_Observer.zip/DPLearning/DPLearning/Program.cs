﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPLearning
{
    class Program
    {
        static List<IObserver> _observers = new List<IObserver>();
        private static ICommand startStopCommand;
        static void Main(string[] args)
        {
            Vehicle vehicle = new Vehicle();
            _observers.Add(new EmailObserver());
            _observers.Add(new SMSObserver());
            startStopCommand = new StartStopCommand(vehicle, _observers);
            Console.WriteLine("Do You want to Start Vehicle?, press Y or N");
            ConsoleKeyInfo key = Console.ReadKey();
            if (key.Key == ConsoleKey.Y)
            {
                Console.WriteLine();
                startStopCommand.Execute("START");
            }
            Console.WriteLine("Do You want to Stop Vehicle?, press Y or N");
            key = Console.ReadKey();
            if (key.Key == ConsoleKey.Y)
            {
                Console.WriteLine();
                startStopCommand.Execute("STOP");
            }

            Console.Read();
        }
    }
}
