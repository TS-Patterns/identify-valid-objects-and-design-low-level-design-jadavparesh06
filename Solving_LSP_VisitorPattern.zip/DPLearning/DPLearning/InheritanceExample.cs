﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: InheritanceExample.cs
// ----------------------------------------------------------------------------------------

using System;

namespace DPLearning
{
    public class A
    {
        public virtual void Test()
        {
            Console.WriteLine("A");
        }

        public void Accept(C obj)
        {
            obj.Fun(this);
        }
    }

    public class B : A
    {
        public override void Test()
        {
            Console.WriteLine("B");
        }

        public new void Accept(D obj)
        {
            obj.Fun(this);
        }
    }
    public class C
    {
        public void Fun(A obj)
        {
            obj.Test();
        }

        public void Fun(B obj)
        {
            obj.Test();
        }
    }

    public class D : C
    {
        public void Fun(A obj)
        {
            obj.Test();
        }

        public void Fun(B obj)
        {
            obj.Test();
        }
    }

}