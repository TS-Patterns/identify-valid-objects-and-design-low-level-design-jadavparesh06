﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPLearning
{
    class Program
    {
        static List<IObserver> _observers = new List<IObserver>();
        private static ICommand startStopCommand;
        static void Main(string[] args)
        {
            InheritanceExampleCode();

            Vehicle vehicle = new Vehicle();
            _observers.Add(new EmailObserver());
            _observers.Add(new SMSObserver());
            startStopCommand = new StartStopCommand(vehicle, _observers);
            Console.WriteLine("Do You want to Start Vehicle?, press Y or N");
            ConsoleKeyInfo key = Console.ReadKey();
            if (key.Key == ConsoleKey.Y)
            {
                Console.WriteLine();
                startStopCommand.Execute("START");
            }
            Console.WriteLine("Do You want to Stop Vehicle?, press Y or N");
            key = Console.ReadKey();
            if (key.Key == ConsoleKey.Y)
            {
                Console.WriteLine();
                startStopCommand.Execute("STOP");
            }

            Console.Read();
        }

        private static void InheritanceExampleCode()
        {

            A obj = new B(); // Substituation
            obj.Test();


            // It doesnot suport two dispatch 
            // static languages like C#, C++, JAVA doesnot support double dispatch
            // Here we know obj is instance of B but still it will call Test of A as it doesnot support double substituaton due to double dispatch problem
            C cobj = new D(); //Substitution
            //cobj.Fun(obj); // here Fun from D will be called with object of A

            obj.Accept(cobj);
        }
    }
}
