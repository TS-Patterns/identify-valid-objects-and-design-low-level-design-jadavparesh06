﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: Vehicle.cs
// ----------------------------------------------------------------------------------------

using System;

namespace DPLearning
{
    /// <summary>
    ///     Vehicle Class
    /// </summary>
    public class Vehicle
    {
        private bool _isVehicleOn;
        public void Start()
        {
            _isVehicleOn = true;
            Console.WriteLine(" Start Vehicle Instruction received.");
        }

        public void Stop()
        {
            _isVehicleOn = false;
            Console.WriteLine(" Stop Vehicle Instruction received.");
        }

        public bool GetVehicleState()
        {
            return _isVehicleOn;
        }
    }
}