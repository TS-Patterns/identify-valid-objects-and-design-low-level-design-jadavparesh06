﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentConvertor_DP_LSPProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            Document doc = new Document();
            doc.Add(new Header());
            doc.Add(new Paragraph());
            doc.Add(new Footer());

            IDocumentConverter converter = new PDFDocumentConverter();
            doc.Convert(converter);

            Console.ReadLine();
        }
    }
}
