﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentConvertor_DP_LSPProblem
{
    public abstract class DocumentPart
    {
        public void Print()
        {
        }

        public void Save()
        {
        }

        public virtual void Convert(IDocumentConverter converter)
        {
            Console.WriteLine($"Convert called for {this.GetType().Name} with converter : " + converter.GetType().Name);
        }
    }
}
