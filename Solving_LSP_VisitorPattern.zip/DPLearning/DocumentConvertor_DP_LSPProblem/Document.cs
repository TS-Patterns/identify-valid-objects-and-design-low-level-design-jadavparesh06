﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DocumentConvertor_DP_LSPProblem
{
    class Document
    {
        private List<DocumentPart> parts = new List<DocumentPart>();

        public void Open()
        {

        }

        public void Save()
        {

        }


        public void Close()
        {

        }

        public void Add(DocumentPart part)
        {
            parts.Add(part);
        }

        public void Convert(IDocumentConverter converter)
        {
            foreach (var part in parts)
            {
                part.Convert(converter);
            }
        }
    }
}
