﻿namespace DocumentConvertor_DP_LSPProblem
{
    public interface IDocumentConverter
    {
        void ConvertParagraph(Paragraph paragraph);

        void ConvertHyperlink(HyperLink href);

        void ConvertFooter(Footer footer);

        void ConvertHeader(Header header);
    }
}