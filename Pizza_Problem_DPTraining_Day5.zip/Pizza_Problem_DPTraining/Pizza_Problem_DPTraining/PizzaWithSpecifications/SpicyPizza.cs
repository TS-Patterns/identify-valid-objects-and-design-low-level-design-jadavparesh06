﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: SpicyPizza.cs
// ----------------------------------------------------------------------------------------

using System;

namespace Pizza_Problem_DPTraining
{
    /// <summary>
    ///     Extra Spicy pizza
    /// </summary>
    public class SpicyPizza : PizzaWithSpecification
    {
        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="pizza"></param>
        public SpicyPizza(Pizza pizza) : base(pizza)
        {

        }

        /// <summary>
        ///      overridden Create Pizza method
        /// </summary>
        public override void CreatePizza()
        {
            AddExtraSpices();
            base.CreatePizza();
        }

        private void AddExtraSpices()
        {
            Console.WriteLine("\nExtra Spices Added");
        }
    }
}