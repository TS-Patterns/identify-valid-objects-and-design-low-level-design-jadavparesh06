﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: PizzaWithSpecification.cs
// ----------------------------------------------------------------------------------------

using System;

namespace Pizza_Problem_DPTraining
{
    public abstract class PizzaWithSpecification : Pizza
    {
        private Pizza _pizza;
        private string _extraSpecification;

        public PizzaWithSpecification(Pizza pizza)
        {
            _pizza = pizza;
        }

        public override void CreatePizza()
        {
            _pizza.CreatePizza();
        }

        private void AddCustomizationForPizza()
        {
            // Add Extra customization here for Pizza as per user's request
            Console.WriteLine($"Customization: {_extraSpecification } Added for {_pizza.GetType().Name}");
        }
    }
}