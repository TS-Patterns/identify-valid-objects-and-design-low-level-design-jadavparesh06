﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_Problem_DPTraining
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaBuilder();
        }

        private static void PizzaBuilder()
        {
            Pizza basePizza;
            Pizza orderedPizza;
            Console.WriteLine("Welcome to YourPizzaHouse!!! Choose Your Pizza, 1) VegItalica or 2) Exotica");
            ConsoleKeyInfo key = Console.ReadKey();
            if (key.Key == ConsoleKey.D1)
            {
                basePizza = new VegItalica();
            }
            else
            {
                basePizza = new Exotica();
            }
            Console.WriteLine("\nExtra Specification : 1) Extra Spicy 2)Cheesy");
            key = Console.ReadKey();
            if (key.Key == ConsoleKey.D1)
            {
                orderedPizza = new SpicyPizza(basePizza);
            }
            else
            {
                orderedPizza = new CheesyPizza(basePizza);
            }
            orderedPizza.CreatePizza();
            Console.Read();
        }
    }
}
