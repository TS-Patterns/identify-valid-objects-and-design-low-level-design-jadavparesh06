﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerAssembling_BuilderPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            ComputerBuilder builder = new LaptopBuilder(new Computer());
            HardwareEngineer engineer = new HardwareEngineer(builder);
            engineer.AssembleComputer();
            var device = engineer.GetComputer();
            Console.Read();
        }
    }
}
