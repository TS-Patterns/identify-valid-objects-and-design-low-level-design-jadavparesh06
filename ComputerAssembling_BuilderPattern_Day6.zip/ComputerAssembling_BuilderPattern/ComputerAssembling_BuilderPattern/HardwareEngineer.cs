﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: HardwareEngineer.cs
// ----------------------------------------------------------------------------------------

namespace ComputerAssembling_BuilderPattern
{
    public class HardwareEngineer
    {
        private ComputerBuilder computerBuilder;

        public HardwareEngineer(ComputerBuilder builder)
        {
            computerBuilder = builder;
        }

        public IDevice GetComputer()
        {
            return computerBuilder?.GetComputer();
        }

        public void AssembleComputer()
        {
            computerBuilder.BuildMotherBoard("MotherBoard1");
            computerBuilder.BuildCPU("CPU1");
            computerBuilder.BuildMemory("Memory1");
            computerBuilder.BuildScreen("Screen1");
        }
    }
}