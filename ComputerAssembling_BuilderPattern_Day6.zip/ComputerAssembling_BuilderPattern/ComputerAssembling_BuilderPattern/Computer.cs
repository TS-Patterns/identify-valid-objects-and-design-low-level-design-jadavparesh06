﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: Computer.cs
// ----------------------------------------------------------------------------------------

namespace ComputerAssembling_BuilderPattern
{
    public class Computer : IDevice
    {
        private string _memory;
        private string _motherBoard;
        private string _screen;
        private string _cpu;


        public void SetMemory(string memory)
        {
            this._memory = memory;
        }

        public void SetMotherBoard(string motheboard)
        {
            this._motherBoard = motheboard;
        }

        public void SetScreen(string screen)
        {
            this._screen = screen;
        }

        public void SetCPU(string cpu)
        {
            this._cpu = cpu;
        }
    }
}