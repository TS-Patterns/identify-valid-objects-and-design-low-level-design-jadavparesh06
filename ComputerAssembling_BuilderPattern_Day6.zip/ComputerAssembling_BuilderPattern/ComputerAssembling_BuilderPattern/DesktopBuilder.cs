﻿// ---------------------------------------------------------------------------------------
// Copyright Koninklijke Philips Electronics N.V. 2020
// 
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
// 
// FILENAME: DesktopBuilder.cs
// ----------------------------------------------------------------------------------------

using System;

namespace ComputerAssembling_BuilderPattern
{
    public class DesktopBuilder : ComputerBuilder
    {
        private Computer _computer;

        public DesktopBuilder(Computer computer)
        {
            _computer = computer;
        }

        public void BuildMemory(string memory)
        {
            _computer.SetMemory(memory);
            Console.WriteLine($"Desktop Memory assembled:{memory}");
        }

        public void BuildMotherBoard(string motherboard)
        {
            _computer.SetMotherBoard(motherboard);
            Console.WriteLine($"Desktop MotherBoard assembled:{motherboard}");
        }

        public void BuildScreen(string screen)
        {
            _computer.SetScreen(screen);
            Console.WriteLine($"Desktop Screen assembled:{screen}");
        }

        public void BuildCPU(string cpu)
        {
            _computer.SetCPU(cpu);
            Console.WriteLine($"Desktop CPU assembled:{cpu}");
        }

        public Computer GetComputer()
        {
            return _computer;
        }
    }
}